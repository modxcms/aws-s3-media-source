<?php
/**
 * @package swift
 */
$xpdo_meta_map['AwsS3MediaSource']= array (
  'package' => 'awss3mediasource',
  'version' => '1.1',
  'extends' => 'modMediaSource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
