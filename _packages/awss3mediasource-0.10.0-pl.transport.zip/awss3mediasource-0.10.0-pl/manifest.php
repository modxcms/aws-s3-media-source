<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '# AWS S3 Media Source

Integration for S3 Media Source

',
    'changelog' => '### 0.10.0
- Make bucket public
- Make driver public
- Add doesObjectExist method
- Add trailing slash to basePath only if it\'s not empty

### 0.9.5
- Use current context if none is passed

### 0.9.4
- Update s3 lib

### 0.9.3
- Transfer files/folders from local Media Source to S3 via cli
- Fix Rename File/Folder and Move Folder
- Limit Media Source to sub directory/folder
- Fix issue with Delete Files/Folders
- Fix Create Directory Here

### 0.9.2
- Remove use statement

### 0.9.1
- Error Logging

### 0.9.0
- S3 Media Source',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'aa68852840b33ce6d9ac76f84746ddb7',
      'native_key' => 'awss3mediasource',
      'filename' => 'modNamespace/d05140f0c3c559799d1cb410a9399a2d.vehicle',
      'namespace' => 'awss3mediasource',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e5adfeddb7a3bd9c1d8a420eb7329c3e',
      'native_key' => NULL,
      'filename' => 'modCategory/c1a9568876b8090623ffccaf7c610b62.vehicle',
      'namespace' => 'awss3mediasource',
    ),
  ),
);