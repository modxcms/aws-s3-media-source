<?php

$xpdo_meta_map = array (
  'modMediaSource' => 
  array (
    0 => 'AwsS3MediaSource',
  ),
);