<?php

$_lang['source_type.awss3mediasource'] = 'AWS S3 Media Source 3.0';
$_lang['source_type.awss3mediasource_desc'] = 'AWS S3 Media Source';
$_lang['prop_s3.baseDir_desc'] = 'S3 folder path, if set will limit Media Source to set folder path.';
$_lang['prop_s3.allowFolderCopy_desc'] = 'Allow S3 folders to be renamed and moved';
$_lang['prop_s3.endpoint_desc'] = 'Alternative S3-compatible endpoint URL, e.g., "https://s3.<region>.backblazeb2.com". Review your S3-compatible provider’s documentation for the endpoint location. Leave empty for Amazon S3';
