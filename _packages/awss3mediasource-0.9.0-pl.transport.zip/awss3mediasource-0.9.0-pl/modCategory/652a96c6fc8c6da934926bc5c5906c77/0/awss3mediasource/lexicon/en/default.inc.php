<?php

$_lang['source_type.awss3mediasource'] = 'AWS S3 Media Source 3.0';
$_lang['source_type.awss3mediasource_desc'] = 'AWS S3 Media Source';