<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 MODX, LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '# AWS S3 Media Source

Integration for S3 Media Source

',
    'changelog' => '- Transfer files/folders from local Media Source to S3 via cli
- Fix Rename File/Folder and Move Folder
- Limit Media Source to sub directory/folder
- Fix issue with Delete Files/Folders
- Fix Create Directory Here

### 0.9.2
- Remove use statement

### 0.9.1
- Error Logging

### 0.9.0
- S3 Media Source',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7ca2246b6b93bc0aef291a7c242dbe31',
      'native_key' => 'awss3mediasource',
      'filename' => 'modNamespace/5a616dc3603b7bcb851a0e4f295449e8.vehicle',
      'namespace' => 'awss3mediasource',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a82cd432915ea29f5c431b77ef2f40d1',
      'native_key' => NULL,
      'filename' => 'modCategory/bdf165ba4a427da12acfecc65774eebe.vehicle',
      'namespace' => 'awss3mediasource',
    ),
  ),
);